# 家計簿 Kakeibo — Catatan Kekayaan Pribadi

PWA jurnal keuangan ala **kakeibo** (Jepang): catat pemasukan & pengeluaran,
lihat kesimpulan lengkap dengan grafik, dan dapatkan saran untuk mempercepat
pertumbuhan kekayaan. 100% offline, data tersimpan di `localStorage`
perangkatmu — tidak ada server, tidak ada tracking.

## Struktur 4 Tab

1. **Pemasukan** — input cepat (grup Active/Irregular/Passive & Financial Income,
   13 sub-kategori) + ringkasan hari ini / bulan ini / tahun ini
2. **Pengeluaran** — input cepat (grup Survival/Optional/Culture/Extra,
   21 sub-kategori) + **pagu bulanan per grup** dengan progress bar otomatis
3. **Kesimpulan** — net worth bulan ini, rasio tabungan, **kalender kakeibo**
   (heatmap harian hijau/merah), grafik garis tren 30 hari, grafik batang
   6 bulan, komposisi pengeluaran vs pedoman ideal kakeibo, dua pie chart
   kualitas pemasukan & kuadran pengeluaran, plus ranking sub-kategori
4. **Saran Boosting** — insight otomatis (rasio tabungan, kuadran Optional,
   sub-kategori terbesar, rasio pendapatan pasif, diversifikasi sumber,
   konsistensi mencatat), refleksi 4 pertanyaan kakeibo klasik, dan
   **ekspor/impor data** (`.json`) untuk backup & pindah perangkat

## 1. Coba langsung di browser / install sebagai PWA

Buka `index.html` langsung, atau host filenya di mana saja (GitHub Pages,
Netlify, dll). Di Chrome Android, buka situsnya lalu **Tambahkan ke Layar
Utama** — aplikasi akan terpasang seperti app native.

## 2. Deploy otomatis ke GitHub Pages + generate APK

Repo ini sudah menyertakan `.github/workflows/build-apk.yml` yang otomatis:

1. Men-deploy semua file PWA ke **GitHub Pages**
2. Membungkusnya jadi **APK Android** terinstal (via Google Bubblewrap /
   Trusted Web Activity) dan mengunggahnya sebagai artifact workflow

### Langkah setup

1. Push folder ini ke repo GitHub baru (root repo = isi folder ini).
2. Buka **Settings → Pages** → pada **Source** pilih **GitHub Actions**.
3. Buka tab **Actions**, jalankan workflow **"Deploy PWA & Build APK"**
   secara manual (`Run workflow`) — atau otomatis berjalan setiap push ke
   `main`.
4. Setelah selesai (job `deploy-pages` lalu `build-apk`), buka hasil run →
   bagian **Artifacts** → unduh `Kakeibo-APK.zip`, di dalamnya ada
   `Kakeibo.apk`.
5. Pindahkan APK ke HP Android, aktifkan **Install dari sumber tidak
   dikenal** untuk file manager/browser yang dipakai, lalu install.

### Catatan soal signing key

Workflow ini men-generate **keystore baru di setiap run** (khusus untuk
sideload/testing pribadi). Ini artinya APK dari run yang berbeda **tidak
bisa saling update** (Android akan minta uninstall dulu). Untuk pemakaian
jangka panjang:

- Generate satu keystore sendiri sekali (`keytool -genkeypair ...`),
- Simpan sebagai GitHub Secret (base64), lalu ubah step
  *"Generate signing keystore"* di workflow untuk memakai secret itu
  alih-alih men-generate baru setiap kali.

### Mengganti nama/paket aplikasi

Edit `twa-manifest.template.json` — field `packageId` (mis.
`id.kakeibo.app` → ganti ke domainmu sendiri) dan `name` /
`launcherName`.

## Struktur file

```
index.html                 shell 4-tab
css/style.css               tema kakeibo (sumi ink + kin gold)
js/app.js                   logika data, kalkulasi, Chart.js
manifest.json                web app manifest (PWA)
sw.js                       service worker (offline cache)
icons/                       ikon 192/512/180
twa-manifest.template.json  template konfigurasi Bubblewrap
.github/workflows/build-apk.yml   CI: deploy Pages + build APK
```

## Privasi & data

Semua transaksi hanya disimpan di `localStorage` browser/WebView-mu.
Tidak ada pengiriman data ke server manapun. Gunakan tombol **Ekspor Data**
di Tab Saran secara berkala untuk membuat cadangan `.json` — file ini bisa
dipulihkan lagi lewat **Impor Data** di perangkat yang sama atau perangkat
lain. Tanpa backup manual ini, menghapus data situs / uninstall APK akan
menghapus seluruh riwayat secara permanen.
