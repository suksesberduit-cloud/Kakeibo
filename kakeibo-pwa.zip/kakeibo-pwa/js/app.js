/* Kakeibo — app.js
   Semua data disimpan di localStorage, 100% offline-first. */

const STORAGE_KEY = 'fukucho_transactions_v1';

const PALETTE = {
  matcha: '#8AA073', gold: '#C9A961', indigo: '#4A7096',
  vermillion: '#C25B3F', clay: '#9A6A4A', plum: '#7A5D7A',
  slate: '#5D7A8A', sand: '#B79A6B'
};

// ---------- Kategori: struktur hierarkis (grup -> sub-kategori) ----------
const INCOME_GROUPS = {
  'Active Income': ['Gaji Pokok', 'Tunjangan', 'Uang Saku/Jajan', 'Insentif/Bonus Rutin'],
  'Irregular Income': ['Proyek/Freelance', 'Keuntungan Bisnis', 'Bonus Tahunan/THR', 'Refund/Cashback', 'Penjualan Barang Bekas'],
  'Passive & Financial Income': ['Dividen Saham/Reksadana', 'Bunga Deposito/P2P Lending', 'Uang Sewa Properti', 'Royalti']
};
const EXPENSE_GROUPS = {
  'Survival': ['Pangan', 'Tempat Tinggal', 'Tagihan Rumah Tangga', 'Komunikasi & Internet', 'Transportasi Harian', 'Kesehatan & Proteksi', 'Hutang/Cicilan'],
  'Optional': ['Kuliner Mandiri', 'Belanja Fashion', 'Perawatan Diri', 'Gaya Hidup & Hobi', 'Traveling & Rekreasi', 'Langganan Hiburan Digital'],
  'Culture': ['Edukasi & Buku', 'Seni & Hiburan Budaya', 'Sosialisasi', 'Kebaikan/Religi'],
  'Extra': ['Darurat Medis', 'Perawatan Aset', 'Pajak & Legalitas', 'Kebutuhan Musiman']
};
const INCOME_GROUP_COLORS = { 'Active Income': PALETTE.matcha, 'Irregular Income': PALETTE.gold, 'Passive & Financial Income': PALETTE.indigo };
const EXPENSE_GROUP_COLORS = { 'Survival': PALETTE.vermillion, 'Optional': PALETTE.clay, 'Culture': PALETTE.plum, 'Extra': PALETTE.slate };
const KAKEIBO_IDEAL = { Survival: 55, Optional: 20, Culture: 10, Extra: 15 };

function buildReverseMap(groups) {
  const map = {};
  Object.entries(groups).forEach(([g, cats]) => cats.forEach(c => { map[c] = g; }));
  return map;
}
const CAT2GROUP_INCOME = buildReverseMap(INCOME_GROUPS);
const CAT2GROUP_EXPENSE = buildReverseMap(EXPENSE_GROUPS);

const CAT_EMOJI = {
  'Gaji Pokok': '💼', 'Tunjangan': '🎟️', 'Uang Saku/Jajan': '👛', 'Insentif/Bonus Rutin': '🏅',
  'Proyek/Freelance': '🧑‍💻', 'Keuntungan Bisnis': '🏪', 'Bonus Tahunan/THR': '🎊', 'Refund/Cashback': '↩️', 'Penjualan Barang Bekas': '📦',
  'Dividen Saham/Reksadana': '📈', 'Bunga Deposito/P2P Lending': '🏦', 'Uang Sewa Properti': '🏠', 'Royalti': '🎼',
  'Pangan': '🍚', 'Tempat Tinggal': '🏠', 'Tagihan Rumah Tangga': '💡', 'Komunikasi & Internet': '📶',
  'Transportasi Harian': '🚗', 'Kesehatan & Proteksi': '💊', 'Hutang/Cicilan': '💳',
  'Kuliner Mandiri': '☕', 'Belanja Fashion': '👗', 'Perawatan Diri': '💇', 'Gaya Hidup & Hobi': '🎮',
  'Traveling & Rekreasi': '✈️', 'Langganan Hiburan Digital': '📺',
  'Edukasi & Buku': '📚', 'Seni & Hiburan Budaya': '🎭', 'Sosialisasi': '🎂', 'Kebaikan/Religi': '🤲',
  'Darurat Medis': '🚑', 'Perawatan Aset': '🔧', 'Pajak & Legalitas': '📜', 'Kebutuhan Musiman': '🎁'
};

// ---------- State ----------
let tx = [];
try { tx = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { tx = []; }

const BUDGET_KEY = 'fukucho_budgets_v1';
let budgets = {};
try { budgets = JSON.parse(localStorage.getItem(BUDGET_KEY)) || {}; } catch (e) { budgets = {}; }
function saveBudgets() { localStorage.setItem(BUDGET_KEY, JSON.stringify(budgets)); }

function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(tx)); }

function todayStr() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function ymStr(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }

const NOW = new Date();
const TODAY = todayStr();
const THIS_YM = ymStr(NOW);
const THIS_YEAR = String(NOW.getFullYear());

// ---------- Formatting ----------
function rupiah(n) {
  const v = Math.round(n || 0);
  return 'Rp' + v.toLocaleString('id-ID');
}
function rupiahShort(n) {
  const v = Math.round(n || 0);
  const abs = Math.abs(v);
  if (abs >= 1_000_000_000) return (v / 1_000_000_000).toFixed(1).replace('.0', '') + 'M';
  if (abs >= 1_000_000) return (v / 1_000_000).toFixed(1).replace('.0', '') + 'jt';
  if (abs >= 1_000) return (v / 1_000).toFixed(0) + 'rb';
  return String(v);
}
function escapeHtml(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ---------- Filters ----------
const isType = (t) => (x) => x.type === t;
const isToday = (x) => x.date === TODAY;
const isThisMonth = (x) => x.date.slice(0, 7) === THIS_YM;
const isThisYear = (x) => x.date.slice(0, 4) === THIS_YEAR;

function sumBy(list) { return list.reduce((a, x) => a + Number(x.amount), 0); }

// ---------- Toast ----------
let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
}

// ---------- Populate category selects (grouped) ----------
function populateSelect(selectEl, groups) {
  selectEl.innerHTML = Object.entries(groups).map(([g, cats]) =>
    `<optgroup label="${escapeHtml(g)}">${cats.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')}</optgroup>`
  ).join('');
}
populateSelect(document.getElementById('inc-category'), INCOME_GROUPS);
populateSelect(document.getElementById('exp-category'), EXPENSE_GROUPS);

// ---------- CRUD ----------
function addTransaction(type, amount, category, note, date) {
  if (!amount || amount <= 0) { toast('Masukkan nominal yang valid'); return false; }
  const useDate = /^\d{4}-\d{2}-\d{2}$/.test(date || '') ? date : TODAY;
  tx.push({
    id: 'tx_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
    type, amount: Number(amount), category, note: (note || '').trim(),
    date: useDate, createdAt: Date.now()
  });
  save();
  return true;
}
function removeTransaction(id) {
  tx = tx.filter(x => x.id !== id);
  save();
  renderAll();
}

// ---------- Date fields default to today ----------
document.getElementById('inc-date').value = TODAY;
document.getElementById('exp-date').value = TODAY;

// ---------- Tab navigation ----------
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('panel-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'summary') renderCharts();
  });
});

// ---------- Today label ----------
document.getElementById('todayLabel').textContent = NOW.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

// ---------- Render: list item ----------
function txItemHtml(item) {
  const emoji = CAT_EMOJI[item.category] || (item.type === 'income' ? '💵' : '🧾');
  const sign = item.type === 'income' ? '+' : '−';
  return `<div class="tx-item ${item.type}" data-id="${item.id}">
    <div class="tx-icon">${emoji}</div>
    <div class="tx-body">
      <div class="tx-cat">${escapeHtml(item.category)}</div>
      <div class="tx-note">${escapeHtml(item.note) || '&nbsp;'}</div>
    </div>
    <div class="tx-amount">${sign}${rupiah(item.amount)}</div>
    <button class="tx-del" aria-label="Hapus">✕</button>
  </div>`;
}

function renderList(containerId, list, emptyMsg) {
  const el = document.getElementById(containerId);
  if (!list.length) {
    el.innerHTML = `<div class="empty-state"><span class="glyph">〜</span>${emptyMsg}</div>`;
    return;
  }
  const sorted = [...list].sort((a, b) => b.createdAt - a.createdAt);
  el.innerHTML = sorted.map(txItemHtml).join('');
  el.querySelectorAll('.tx-del').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.target.closest('.tx-item').dataset.id;
      removeTransaction(id);
    });
  });
}

// ---------- Render: Tab 1 & 2 ----------
function renderIncomeTab() {
  const inc = tx.filter(isType('income'));
  document.getElementById('inc-today').textContent = rupiah(sumBy(inc.filter(isToday)));
  document.getElementById('inc-month').textContent = rupiah(sumBy(inc.filter(isThisMonth)));
  document.getElementById('inc-year').textContent = rupiah(sumBy(inc.filter(isThisYear)));
  renderList('inc-list-today', inc.filter(isToday), 'Belum ada pemasukan hari ini');
  renderList('inc-list-month', inc.filter(isThisMonth), 'Belum ada pemasukan bulan ini');
}
function renderExpenseTab() {
  const exp = tx.filter(isType('expense'));
  document.getElementById('exp-today').textContent = rupiah(sumBy(exp.filter(isToday)));
  document.getElementById('exp-month').textContent = rupiah(sumBy(exp.filter(isThisMonth)));
  document.getElementById('exp-year').textContent = rupiah(sumBy(exp.filter(isThisYear)));
  renderList('exp-list-today', exp.filter(isToday), 'Belum ada pengeluaran hari ini');
  renderList('exp-list-month', exp.filter(isThisMonth), 'Belum ada pengeluaran bulan ini');
  renderBudgetSection();
}

function renderBudgetSection() {
  const el = document.getElementById('budget-list');
  const spendMap = Object.fromEntries(groupBreakdown('expense'));
  el.innerHTML = Object.keys(EXPENSE_GROUPS).map(g => {
    const budget = budgets[g] || 0;
    const spent = spendMap[g] || 0;
    const pct = budget > 0 ? (spent / budget) * 100 : 0;
    const barColor = !budget ? PALETTE.slate : pct >= 100 ? PALETTE.vermillion : pct >= 80 ? PALETTE.gold : EXPENSE_GROUP_COLORS[g];
    const status = budget
      ? `${rupiah(spent)} / ${rupiah(budget)} (${pct.toFixed(0)}%)${pct >= 100 ? ' — pagu terlampaui' : ''}`
      : `${rupiah(spent)} terpakai bulan ini — pagu belum diatur`;
    return `<div class="budget-row">
      <div class="budget-top">
        <span class="budget-name"><span class="sw" style="background:${EXPENSE_GROUP_COLORS[g]}"></span>${escapeHtml(g)}</span>
        <span class="budget-input-wrap">Rp<input type="number" inputmode="numeric" class="budget-input" data-group="${escapeHtml(g)}" value="${budget || ''}" placeholder="atur pagu"></span>
      </div>
      <div class="rank-track"><div class="rank-fill" style="width:${Math.max(0, Math.min(100, pct))}%;background:${barColor}"></div></div>
      <div class="budget-status">${status}</div>
    </div>`;
  }).join('');

  el.querySelectorAll('.budget-input').forEach(inp => {
    inp.addEventListener('change', (e) => {
      const g = e.target.dataset.group;
      budgets[g] = Number(e.target.value) || 0;
      saveBudgets();
      renderBudgetSection();
    });
  });
}

document.getElementById('inc-submit').addEventListener('click', () => {
  const amt = document.getElementById('inc-amount').value;
  const cat = document.getElementById('inc-category').value;
  const note = document.getElementById('inc-note').value;
  const date = document.getElementById('inc-date').value;
  if (addTransaction('income', amt, cat, note, date)) {
    document.getElementById('inc-amount').value = '';
    document.getElementById('inc-note').value = '';
    document.getElementById('inc-date').value = TODAY;
    toast('Pemasukan dicatat ✓');
    renderAll();
  }
});
document.getElementById('exp-submit').addEventListener('click', () => {
  const amt = document.getElementById('exp-amount').value;
  const cat = document.getElementById('exp-category').value;
  const note = document.getElementById('exp-note').value;
  const date = document.getElementById('exp-date').value;
  if (addTransaction('expense', amt, cat, note, date)) {
    document.getElementById('exp-amount').value = '';
    document.getElementById('exp-note').value = '';
    document.getElementById('exp-date').value = TODAY;
    toast('Pengeluaran dicatat ✓');
    renderAll();
  }
});

// ---------- Render: Tab 3 (Kesimpulan) ----------
let charts = {};
function destroyChart(key) { if (charts[key]) { charts[key].destroy(); delete charts[key]; } }

function renderSummaryHero() {
  const incM = sumBy(tx.filter(isType('income')).filter(isThisMonth));
  const expM = sumBy(tx.filter(isType('expense')).filter(isThisMonth));
  const net = incM - expM;
  const rate = incM > 0 ? Math.max(0, Math.min(100, (net / incM) * 100)) : 0;

  document.getElementById('sum-net-month').textContent = (net >= 0 ? '+' : '−') + rupiah(Math.abs(net));
  document.getElementById('sum-net-month').style.color = net >= 0 ? 'var(--matcha)' : 'var(--vermillion)';
  document.getElementById('sum-inc-mini').textContent = rupiah(incM);
  document.getElementById('sum-exp-mini').textContent = rupiah(expM);
  document.getElementById('sum-rate-bar').style.width = rate.toFixed(0) + '%';
  document.getElementById('sum-rate-label').textContent = rate.toFixed(0) + '% dari pemasukan tersimpan';
}

function last30Days() {
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
  }
  return days;
}
function last6Months() {
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    months.push({ key: ymStr(d), label: d.toLocaleDateString('id-ID', { month: 'short' }) });
  }
  return months;
}

function renderTrendChart() {
  const days = last30Days();
  const incData = days.map(d => sumBy(tx.filter(x => x.type === 'income' && x.date === d)));
  const expData = days.map(d => sumBy(tx.filter(x => x.type === 'expense' && x.date === d)));
  const labels = days.map(d => d.slice(8, 10));

  destroyChart('trend');
  const ctx = document.getElementById('chartTrend');
  charts.trend = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label: 'Pemasukan', data: incData, borderColor: PALETTE.matcha, backgroundColor: 'rgba(138,160,115,0.15)', tension: 0.35, fill: true, pointRadius: 0, borderWidth: 2 },
        { label: 'Pengeluaran', data: expData, borderColor: PALETTE.vermillion, backgroundColor: 'rgba(194,91,63,0.12)', tension: 0.35, fill: true, pointRadius: 0, borderWidth: 2 }
      ]
    },
    options: {
      responsive: true,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top', labels: { color: '#9AA3AC', boxWidth: 10, font: { size: 10.5 } } },
        tooltip: { callbacks: { label: (c) => c.dataset.label + ': ' + rupiah(c.raw) } }
      },
      scales: {
        x: { ticks: { color: '#5D6670', font: { size: 9 }, maxTicksLimit: 8 }, grid: { display: false } },
        y: { ticks: { color: '#5D6670', font: { size: 9 }, callback: (v) => rupiahShort(v) }, grid: { color: '#2A333D' } }
      }
    }
  });
}

function renderBarChart() {
  const months = last6Months();
  const incData = months.map(m => sumBy(tx.filter(x => x.type === 'income' && x.date.slice(0, 7) === m.key)));
  const expData = months.map(m => sumBy(tx.filter(x => x.type === 'expense' && x.date.slice(0, 7) === m.key)));
  const netData = months.map((m, i) => incData[i] - expData[i]);

  destroyChart('bar');
  const ctx = document.getElementById('chartBar');
  charts.bar = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: months.map(m => m.label),
      datasets: [
        { label: 'Pemasukan', data: incData, backgroundColor: PALETTE.matcha, borderRadius: 4, maxBarThickness: 16 },
        { label: 'Pengeluaran', data: expData, backgroundColor: PALETTE.vermillion, borderRadius: 4, maxBarThickness: 16 },
        { label: 'Net', data: netData, type: 'line', borderColor: PALETTE.gold, backgroundColor: PALETTE.gold, tension: 0.3, borderWidth: 2, pointRadius: 3, pointBackgroundColor: PALETTE.gold }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: 'top', labels: { color: '#9AA3AC', boxWidth: 10, font: { size: 10.5 } } },
        tooltip: { callbacks: { label: (c) => c.dataset.label + ': ' + rupiah(c.raw) } }
      },
      scales: {
        x: { ticks: { color: '#5D6670', font: { size: 10 } }, grid: { display: false } },
        y: { ticks: { color: '#5D6670', font: { size: 9 }, callback: (v) => rupiahShort(v) }, grid: { color: '#2A333D' } }
      }
    }
  });
}

// Sub-kategori breakdown bulan ini (untuk rank list & pie legend)
function categoryBreakdown(type) {
  const list = tx.filter(x => x.type === type && isThisMonth(x));
  const map = {};
  list.forEach(x => { map[x.category] = (map[x.category] || 0) + Number(x.amount); });
  return Object.entries(map).sort((a, b) => b[1] - a[1]);
}

// Grup breakdown bulan ini (Active/Irregular/Passive atau Survival/Optional/Culture/Extra)
function groupBreakdown(type) {
  const groups = type === 'income' ? INCOME_GROUPS : EXPENSE_GROUPS;
  const cat2group = type === 'income' ? CAT2GROUP_INCOME : CAT2GROUP_EXPENSE;
  const list = tx.filter(x => x.type === type && isThisMonth(x));
  const sums = {};
  list.forEach(x => {
    const g = cat2group[x.category] || 'Lainnya';
    sums[g] = (sums[g] || 0) + Number(x.amount);
  });
  return Object.keys(groups).map(g => [g, sums[g] || 0]);
}

function renderGroupPie(canvasId, legendId, type) {
  const colors = type === 'income' ? INCOME_GROUP_COLORS : EXPENSE_GROUP_COLORS;
  const raw = groupBreakdown(type);
  const entries = raw.filter(([, v]) => v > 0);
  const key = type + 'Pie';
  destroyChart(key);
  const ctx = document.getElementById(canvasId);
  const legend = document.getElementById(legendId);

  if (!entries.length) {
    legend.innerHTML = `<li style="justify-content:center;">Belum ada data bulan ini</li>`;
    return;
  }

  const labels = entries.map(e => e[0]);
  const data = entries.map(e => e[1]);
  const total = data.reduce((a, b) => a + b, 0);
  const colorList = labels.map(l => colors[l]);

  charts[key] = new Chart(ctx, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colorList, borderColor: '#1B222A', borderWidth: 2 }] },
    options: {
      responsive: true,
      cutout: '62%',
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: (c) => c.label + ': ' + rupiah(c.raw) + ' (' + ((c.raw / total) * 100).toFixed(0) + '%)' } }
      }
    }
  });

  legend.innerHTML = entries.map(([g, v]) => `<li><span class="sw" style="background:${colors[g]}"></span>${escapeHtml(g)}<b>${((v / total) * 100).toFixed(0)}%</b></li>`).join('');
}

function renderKakeiboMix() {
  const raw = groupBreakdown('expense');
  const total = raw.reduce((a, [, v]) => a + v, 0);
  const labels = raw.map(([g]) => g);
  const actual = raw.map(([, v]) => total > 0 ? (v / total * 100) : 0);
  const ideal = raw.map(([g]) => KAKEIBO_IDEAL[g] || 0);

  destroyChart('mix');
  const ctx = document.getElementById('chartKakeiboMix');
  charts.mix = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Realisasi', data: actual, backgroundColor: labels.map(g => EXPENSE_GROUP_COLORS[g]), borderRadius: 5, maxBarThickness: 26 },
        { label: 'Pedoman Ideal', data: ideal, backgroundColor: 'rgba(201,169,97,0.22)', borderColor: PALETTE.gold, borderWidth: 1.5, borderRadius: 5, maxBarThickness: 26 }
      ]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      plugins: {
        legend: { position: 'top', labels: { color: '#9AA3AC', boxWidth: 10, font: { size: 10.5 } } },
        tooltip: { callbacks: { label: (c) => c.dataset.label + ': ' + c.raw.toFixed(0) + '%' } }
      },
      scales: {
        x: { ticks: { color: '#5D6670', font: { size: 9 }, callback: (v) => v + '%' }, grid: { color: '#2A333D' }, max: Math.max(70, ...actual, ...ideal) + 10 },
        y: { ticks: { color: '#9AA3AC', font: { size: 11, weight: '600' } }, grid: { display: false } }
      }
    }
  });

  const legend = document.getElementById('legendKakeiboMix');
  legend.innerHTML = raw.map(([g], i) => {
    const diff = actual[i] - ideal[i];
    const flag = total === 0 ? '' : diff > 5 ? ' · di atas pedoman' : diff < -5 ? ' · di bawah pedoman' : ' · sesuai pedoman';
    return `<li><span class="sw" style="background:${EXPENSE_GROUP_COLORS[g]}"></span>${escapeHtml(g)}<b>${actual[i].toFixed(0)}% / ${ideal[i]}%${total > 0 ? flag : ''}</b></li>`;
  }).join('') + `<div class="benchmark-note">Realisasi = porsi aktual bulan ini. Pedoman ideal (Survival 55% · Optional 20% · Culture 10% · Extra 15%) adalah panduan umum kakeibo, bukan aturan baku — sesuaikan dengan kondisimu.</div>`;
}

function renderRankList(containerId, type) {
  const entries = categoryBreakdown(type);
  const groupMap = type === 'income' ? CAT2GROUP_INCOME : CAT2GROUP_EXPENSE;
  const groupColors = type === 'income' ? INCOME_GROUP_COLORS : EXPENSE_GROUP_COLORS;
  const el = document.getElementById(containerId);
  if (!entries.length) {
    el.innerHTML = `<div class="empty-state"><span class="glyph">〜</span>Belum ada data bulan ini</div>`;
    return;
  }
  const max = entries[0][1];
  el.innerHTML = entries.slice(0, 8).map(([cat, amt]) => {
    const group = groupMap[cat] || 'Lainnya';
    const color = groupColors[group] || PALETTE.slate;
    const pct = max > 0 ? (amt / max * 100) : 0;
    return `<div class="rank-row">
      <div class="rank-top"><span class="rank-name">${escapeHtml(cat)}<span class="rank-group">${escapeHtml(group)}</span></span><span class="rank-amount">${rupiah(amt)}</span></div>
      <div class="rank-track"><div class="rank-fill" style="width:${pct}%;background:${color}"></div></div>
    </div>`;
  }).join('');
}

let selectedCalDay = NOW.getDate();

function renderCalendar() {
  const el = document.getElementById('calendarGrid');
  const year = NOW.getFullYear(), month = NOW.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const startWeekday = new Date(year, month, 1).getDay();

  const dayData = {};
  tx.filter(isThisMonth).forEach(x => {
    const d = Number(x.date.slice(8, 10));
    if (!dayData[d]) dayData[d] = { income: 0, expense: 0 };
    dayData[d][x.type] += Number(x.amount);
  });

  let maxAbs = 1;
  Object.values(dayData).forEach(d => { maxAbs = Math.max(maxAbs, Math.abs(d.income - d.expense)); });

  const dow = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
  let html = dow.map(d => `<div class="cal-dow">${d}</div>`).join('');
  for (let i = 0; i < startWeekday; i++) html += `<div class="cal-cell empty"></div>`;

  for (let d = 1; d <= daysInMonth; d++) {
    const data = dayData[d];
    let bg = 'var(--ink-soft)';
    if (data) {
      const net = data.income - data.expense;
      const intensity = Math.max(0.3, Math.min(1, Math.abs(net) / maxAbs));
      bg = net >= 0 ? `rgba(138,160,115,${intensity})` : `rgba(194,91,63,${intensity})`;
    }
    const isTodayCell = d === NOW.getDate();
    const isSelected = d === selectedCalDay;
    html += `<div class="cal-cell${isTodayCell ? ' today' : ''}${isSelected ? ' selected' : ''}" data-day="${d}" style="background:${bg}">${d}</div>`;
  }
  el.innerHTML = html;

  el.querySelectorAll('.cal-cell[data-day]').forEach(cell => {
    cell.addEventListener('click', () => {
      selectedCalDay = Number(cell.dataset.day);
      el.querySelectorAll('.cal-cell.selected').forEach(c => c.classList.remove('selected'));
      cell.classList.add('selected');
      renderCalDetail();
    });
  });

  renderCalDetail();
}

function renderCalDetail() {
  const el = document.getElementById('calDetail');
  const d = selectedCalDay;
  if (!d) { el.innerHTML = ''; return; }

  const dateStr = THIS_YM + '-' + String(d).padStart(2, '0');
  const dayTx = tx.filter(x => x.date === dateStr);
  const dayInc = sumBy(dayTx.filter(x => x.type === 'income'));
  const dayExp = sumBy(dayTx.filter(x => x.type === 'expense'));
  const dayNet = dayInc - dayExp;

  const cumTx = tx.filter(x => isThisMonth(x) && Number(x.date.slice(8, 10)) <= d);
  const cumInc = sumBy(cumTx.filter(x => x.type === 'income'));
  const cumExp = sumBy(cumTx.filter(x => x.type === 'expense'));
  const cumNet = cumInc - cumExp;

  const dateLabel = new Date(NOW.getFullYear(), NOW.getMonth(), d).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });
  const sortedDayTx = [...dayTx].sort((a, b) => b.createdAt - a.createdAt);

  el.innerHTML = `
    <div class="cal-detail-head">${dateLabel}</div>
    <div class="cal-detail-row"><span>Net hari ini</span><b class="${dayNet >= 0 ? 'pos' : 'neg'}">${dayNet >= 0 ? '+' : '−'}${rupiah(Math.abs(dayNet))}</b></div>
    <div class="cal-detail-sub">Masuk ${rupiah(dayInc)} · Keluar ${rupiah(dayExp)}</div>
    ${sortedDayTx.length
      ? '<div class="cal-detail-list">' + sortedDayTx.map(x => `<div class="cal-detail-item"><span>${escapeHtml(x.category)}</span><b class="${x.type === 'income' ? 'pos' : 'neg'}">${x.type === 'income' ? '+' : '−'}${rupiah(x.amount)}</b></div>`).join('') + '</div>'
      : '<div class="cal-detail-empty">Tidak ada transaksi tanggal ini</div>'}
    <div class="cal-detail-divider"></div>
    <div class="cal-detail-head-sm">Kumulatif s.d. tanggal ${d}</div>
    <div class="cal-detail-row"><span>Net bulan berjalan</span><b class="${cumNet >= 0 ? 'pos' : 'neg'}">${cumNet >= 0 ? '+' : '−'}${rupiah(Math.abs(cumNet))}</b></div>
    <div class="cal-detail-sub">Masuk ${rupiah(cumInc)} · Keluar ${rupiah(cumExp)}</div>
  `;
}

function renderCharts() {
  renderSummaryHero();
  renderCalendar();
  renderTrendChart();
  renderBarChart();
  renderKakeiboMix();
  renderGroupPie('chartPieIncome', 'legendIncome', 'income');
  renderGroupPie('chartPieExpense', 'legendExpense', 'expense');
  renderRankList('rankIncome', 'income');
  renderRankList('rankExpense', 'expense');
}

// ---------- Render: Tab 4 (Saran Boosting) ----------
function renderAdvice() {
  const incM = sumBy(tx.filter(isType('income')).filter(isThisMonth));
  const expM = sumBy(tx.filter(isType('expense')).filter(isThisMonth));
  const net = incM - expM;
  const rate = incM > 0 ? (net / incM) * 100 : 0;
  const expByCat = categoryBreakdown('expense');
  const topCat = expByCat[0];
  const expByGroup = groupBreakdown('expense');
  const incByGroup = groupBreakdown('income');

  const cards = [];

  // Savings rate assessment
  if (incM === 0) {
    cards.push({ tag: 'Mulai', title: 'Catat pemasukanmu dulu', body: 'Isi Tab Pemasukan agar Kakeibo bisa menghitung rasio tabungan dan memberi saran yang akurat.', type: '' });
  } else if (rate >= 20) {
    cards.push({ tag: 'Kerja Bagus', title: `Rasio tabungan ${rate.toFixed(0)}% — di atas standar 20%`, body: 'Pertahankan ritme ini. Pertimbangkan mengalihkan sebagian surplus ke instrumen investasi agar uangmu bekerja, bukan hanya mengendap.', type: 'good' });
  } else if (rate >= 0) {
    cards.push({ tag: 'Perlu Dorongan', title: `Rasio tabungan baru ${rate.toFixed(0)}%`, body: 'Target sehat ala kakeibo adalah menabung minimal 20% dari pemasukan. Coba naikkan bertahap 2–3% tiap bulan lewat pos pengeluaran terbesarmu.', type: '' });
  } else {
    cards.push({ tag: 'Peringatan', title: 'Pengeluaran melebihi pemasukan bulan ini', body: 'Kekayaanmu menyusut bulan ini. Prioritaskan memangkas kategori Optional & Extra di bawah, dan tunda pembelian besar sampai arus kas positif kembali.', type: 'urgent' });
  }

  // Kakeibo quadrant deviation (Optional group vs ideal)
  if (expM > 0) {
    const optional = expByGroup.find(([g]) => g === 'Optional');
    const optPct = optional ? (optional[1] / expM) * 100 : 0;
    const diff = optPct - KAKEIBO_IDEAL.Optional;
    if (diff > 8) {
      cards.push({ tag: 'Kuadran Optional', title: `Pos "Keinginan & Hiburan" ${optPct.toFixed(0)}% dari total pengeluaran`, body: `Ini ${diff.toFixed(0)} poin di atas pedoman kakeibo (20%). Coba tetapkan pagu mingguan untuk kuliner mandiri, hiburan digital, atau belanja fashion agar porsi Survival & tabungan tidak tergerus.`, type: 'urgent' });
    } else {
      cards.push({ tag: 'Kuadran Optional', title: `Pos "Keinginan & Hiburan" terkendali di ${optPct.toFixed(0)}%`, body: 'Porsi keinginan & hiburanmu masih sejalan dengan pedoman kakeibo — keseimbangan yang sehat antara menikmati hidup dan menabung.', type: 'good' });
    }
  }

  // Top subcategory insight
  if (topCat) {
    const pct = incM > 0 ? (topCat[1] / incM) * 100 : 0;
    cards.push({
      tag: 'Sub-kategori Terbesar',
      title: `${topCat[0]} — ${rupiah(topCat[1])}`,
      body: pct > 30
        ? `Sub-kategori ini menyerap ${pct.toFixed(0)}% dari total pemasukanmu bulan ini. Coba tetapkan pagu (budget cap) mingguan khusus untuk pos ini.`
        : `Ini pos pengeluaran terbesarmu bulan ini (${pct.toFixed(0)}% dari pemasukan) — masih dalam batas wajar, tapi tetap layak dipantau.`,
      type: pct > 30 ? 'urgent' : ''
    });
  }

  // Passive income ratio
  if (incM > 0) {
    const passive = incByGroup.find(([g]) => g === 'Passive & Financial Income');
    const passivePct = passive ? (passive[1] / incM) * 100 : 0;
    if (passivePct >= 20) {
      cards.push({ tag: 'Pendapatan Pasif', title: `Rasio pendapatan pasif ${passivePct.toFixed(0)}%`, body: 'Kualitas pemasukanmu kuat — seperlima atau lebih berasal dari dividen, sewa, bunga, atau royalti. Ini fondasi penting menuju kebebasan finansial.', type: 'good' });
    } else if (passivePct > 0) {
      cards.push({ tag: 'Pendapatan Pasif', title: `Rasio pendapatan pasif baru ${passivePct.toFixed(0)}%`, body: 'Sebagian kecil pemasukanmu sudah bersifat pasif. Naikkan bertahap lewat reinvestasi dividen atau menambah aset produktif (reksadana, P2P, properti sewa).', type: '' });
    } else {
      cards.push({ tag: 'Pendapatan Pasif', title: 'Belum ada pendapatan pasif tercatat', body: 'Seluruh pemasukanmu masih dari kerja aktif. Mulai dari nominal kecil di dividen/reksadana atau deposito untuk membangun aliran pasif pertamamu.', type: '' });
    }
  }

  // Income diversification
  const incByCat = categoryBreakdown('income');
  if (incByCat.length === 1 && incM > 0) {
    cards.push({ tag: 'Diversifikasi', title: 'Sumber pemasukan masih tunggal', body: `Seluruh pemasukanmu bulan ini berasal dari "${incByCat[0][0]}". Menambah aliran kedua (proyek freelance, dividen, sewa) akan mempercepat pertumbuhan kekayaan dan mengurangi risiko.`, type: '' });
  } else if (incByCat.length >= 3) {
    cards.push({ tag: 'Diversifikasi', title: `${incByCat.length} sumber pemasukan aktif`, body: 'Portofolio pemasukanmu sudah terdiversifikasi — ini menstabilkan kekayaan jangka panjang. Terus perkuat sumber dengan margin terbesar.', type: 'good' });
  }

  // Daily consistency nudge
  const daysWithEntry = new Set(tx.filter(isThisMonth).map(x => x.date)).size;
  const dayOfMonth = NOW.getDate();
  const consistency = dayOfMonth > 0 ? (daysWithEntry / dayOfMonth) * 100 : 0;
  if (consistency < 50 && tx.length > 0) {
    cards.push({ tag: 'Konsistensi', title: 'Pencatatan belum rutin', body: `Baru ${daysWithEntry} dari ${dayOfMonth} hari bulan ini tercatat. Semangat kakeibo adalah kesadaran harian — coba catat setiap transaksi di hari yang sama agar polanya akurat.`, type: '' });
  }

  document.getElementById('advice-list').innerHTML = cards.map(c => `
    <div class="advice-card ${c.type}">
      <span class="advice-tag">${c.tag}</span>
      <h3>${c.title}</h3>
      <p>${c.body}</p>
    </div>`).join('');

  // Kakeibo 4 questions
  document.getElementById('kk-q1').textContent = `${net >= 0 ? '+' : '−'}${rupiah(Math.abs(net))} (pemasukan ${rupiah(incM)} − pengeluaran ${rupiah(expM)})`;
  document.getElementById('kk-q3').textContent = `${rupiah(expM)} sudah dibelanjakan bulan ini, terbesar di ${topCat ? topCat[0] : '—'}`;
  const target20 = incM * 0.2;
  document.getElementById('kk-q2').textContent = incM > 0 ? `Target 20%: ${rupiah(target20)} — realisasi saat ini ${rupiah(Math.max(net, 0))}` : 'Target disarankan: 20% dari pemasukan';
  document.getElementById('kk-q4').textContent = topCat
    ? `Kurangi ${topCat[0]} sebesar 10% bulan depan untuk menaikkan rasio tabungan.`
    : 'Tetapkan satu kebiasaan hemat baru untuk bulan depan.';
}

// ---------- Backup: Export & Import ----------
function exportData() {
  const payload = { app: 'kakeibo', version: 1, exportedAt: new Date().toISOString(), transactions: tx, budgets };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `kakeibo-backup-${TODAY}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  toast('Data diekspor ✓');
}
document.getElementById('btn-export').addEventListener('click', exportData);

document.getElementById('file-import').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      const incoming = Array.isArray(data.transactions) ? data.transactions : (Array.isArray(data) ? data : null);
      if (!incoming) throw new Error('Format file tidak dikenali');
      const ok = window.confirm(`File berisi ${incoming.length} transaksi. Impor akan MENGGANTI seluruh data yang ada saat ini. Lanjutkan?`);
      if (!ok) { e.target.value = ''; return; }
      tx = incoming;
      save();
      if (data.budgets && typeof data.budgets === 'object') { budgets = data.budgets; saveBudgets(); }
      toast('Data berhasil diimpor ✓');
      renderAll();
    } catch (err) {
      toast('Gagal impor: file tidak valid');
    }
    e.target.value = '';
  };
  reader.readAsText(file);
});

// ---------- Render all ----------
function renderAll() {
  renderIncomeTab();
  renderExpenseTab();
  renderAdvice();
  if (document.getElementById('panel-summary').classList.contains('active')) renderCharts();
}
renderAll();

// ---------- Service worker ----------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}
